# import DevsExpo

zee5 = "https://userapi.zee5.com/v1/user/loginemail?email={email}&password={password}"
nord = "https://zwyr157wwiu6eior.com/v1/users/tokens"
vortex = "https://vortex-api.gg/login"
vypr = "https://api.goldenfrog.com/settings"
